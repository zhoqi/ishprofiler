% Demo1
% the global ratios for all 71 tissue cores. A sample tissue core image, 
% superimposed with detected and classified DISH gene and CEP signals, 
% where PTEN signal is black, CEP10 is red, and mixed classes PTEN+CEP10 is 
% green.
%
% Qing Zhong, USZ/UZH, qing.zhong@usz.ch, 13.08,2015

%% detect and classify points
clear all
seed = RandStream('mt19937ar','Seed',1);
RandStream.setGlobalStream(seed);
pctRunOnAll warning('off','all')

addpath(genpath('libsvm-3.18/matlab')) 
%imagepath = 'images/';
imagepath = '/Users/qingzhong/Dropbox (Wildlab)/Hamamatsu/';

% read TMA information
T = readtable('demo1.xlsx');
labels = T.Label; % annotation
files = T.Loc; % TMA

% trained and validated SVM model
load model.mat; 

% initialization
dim = length(imread(strcat(imagepath, files{1}, '.jpg'))); % image size
r = 3; % point signal radius
len = length(files);
pos = cell(len,1);
gRatio = zeros(len,1); % global ratio

tic
parfor n = 1:len % using "porfor" for parallel computing
    % read image
    img = imread(strcat(imagepath, files{n}, '.jpg'));
    % find point signals
    [circen, cirrad, metric] = imfindcircles(img,[r-2 r+4],'ObjectPolarity','dark');
    % classify point signals and get their positions
    [cep, gene] = classifyPoints(img, circen, r, model);
    % save results
    pos{n} =struct('cep', cep, 'gene', gene);  
    gRatio(n) = length(gene)/length(cep);
end
toc

% clipping
gRatio(gRatio > 3) = 3;

fffff

save demo1.mat

%% ploting a sample image
n = 66;
figure
imshow(strcat(imagepath, files{n}, '.jpg'));
hold on
ps = [pos{n}.cep; pos{n}.gene];
scatter(ps(:,1), ps(:,2), 10, ps(:,3:end));
title(files{n}, 'Interpreter', 'none')