function [rat, den]= RLRD(dim, pos, radius, nPts)
% RLRD Calculates the randomized local ratio and the randomized local 
% density as distribution
%
% Qing Zhong, USZ/UZH, qing.zhong@usz.ch, 14.08,2015


%% get random points for each TMA or all TAMs
randPos = rdnPts(dim/2,dim/2,dim/2.5,nPts);
rp = [randPos.x randPos.y];

D = pdist2(rp,pos.cep(:,1:2));
[B I] = sort(D,2);
cepP = pos.cep(I(:,1),1:2);
D1 = pdist2(cepP,pos.gene(:,1:2));
D2 = pdist2(cepP,pos.cep(:,1:2));
rat = [];
den = [];

for i = 1:nPts
    idx = D1(i,:) < radius;
    idx2 = D2(i,:) < radius;
    if sum(idx) ~= 0
        rat = [rat; sum(idx)/sum(idx2)];
        den = [den; sum(idx)+sum(idx2)];
    end
end
