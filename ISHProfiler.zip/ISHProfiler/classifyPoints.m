function [cep, gene] = classifyPoints(img, circen, r, model)
% CLASSIFYPOINTS Classifies point signals and get their positions
% Using SVM model to classify detected point signals
% LIBSVM was used as the SVM library
%
% Qing Zhong, USZ/UZH, qing.zhong@usz.ch, 14.08,2015

%% defining colors for 5 classes
colors = {[1 0 0]; [0 0 0]; [0.9 0.9 0.9]; [0 0 1]; [0.2510 0.8784 0.8157]}; 
cep = [];
gene = [];

for n = 1 : size(circen, 1) 
    try  
        x = floor(circen(n,1));
        y = floor(circen(n,2));
        xdata = img(y-r : y+r, x-r : x+r, :);
    catch exception
        continue;
    end
    xdata = reshape(xdata,1,(2*r+1)*(2*r+1)*r);
    xdata = double(xdata)/255;
    [I, accuracy, dec_values] = svmpredict(1, xdata, model);

    switch I
    case 1
        cep = [cep; x,y,colors{I}];
    case 2
        gene = [gene; x,y,colors{I}];
    case 5 
        cep = [cep; x,y,colors{I}];
        gene = [gene; x,y,colors{I}];
    otherwise
        % do nothing
    end
end

